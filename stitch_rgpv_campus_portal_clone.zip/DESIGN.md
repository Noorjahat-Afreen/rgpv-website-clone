---
name: Academic Prestige Institutional System
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#43474e'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f88'
  primary: '#002045'
  on-primary: '#ffffff'
  primary-container: '#1a365d'
  on-primary-container: '#86a0cd'
  inverse-primary: '#adc7f7'
  secondary: '#a9353b'
  on-secondary: '#ffffff'
  secondary-container: '#ff7578'
  on-secondary-container: '#720819'
  tertiary: '#361900'
  on-tertiary: '#ffffff'
  tertiary-container: '#552b00'
  on-tertiary-container: '#eb851c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#adc7f7'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#2d476f'
  secondary-fixed: '#ffdad9'
  secondary-fixed-dim: '#ffb3b2'
  on-secondary-fixed: '#410008'
  on-secondary-fixed-variant: '#881c26'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display-hero:
    fontFamily: Merriweather
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Merriweather
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Merriweather
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Merriweather
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Merriweather
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-ticker:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses the dignity, authority, and technological rigor of a premier state technological university. It balances modern digital service accessibility with deep-rooted academic heritage, eliminating bureaucratic friction while preserving official institutional gravitas.

The design movement combines **Corporate Modern** with **Refined Editorial Institutionalism**:
- **Structured Precision:** Crisp grid alignments, clean dividing rules, and disciplined information hierarchy replacing cluttered government portal tropes.
- **Academic Authority:** Subdued parchment and light-slate canvases paired with deep collegiate blues, restrained crimson highlights, and ceremonial gold markers.
- **Democratic Clarity:** Built strictly for student, faculty, and administrative ergonomics—optimizing high-density data such as exam timetables, grade cards, and official gazette notifications with instantaneous scannability.

## Colors

The palette establishes an unmistakable aura of academic prestige and constitutional public trust:

- **Primary (`#1a365d` - Deep Chancellor Navy):** The structural core used for institutional banners, mastheads, major headings, key callouts, and primary active states.
- **Secondary Accent (`#8b1e28` - Academic Crimson):** Signifies official decrees, urgent notices, critical portals (e.g., examination forms, fee deadlines), and solemn alerts.
- **Tertiary Highlight (`#d97706` - Saffron Gold):** Used purposefully for honor rolls, merit badges, "New" status tags, and focus highlights.
- **Neutral Hierarchy (`#1e293b` - Slate Ink):** Deep, legible slate for core typography, supported by `#64748b` for administrative metadata. 
- **Surface Canvases:** Grounded in clinical slate whites (`#f8fafc` surface background, `#ffffff` card elevations, `#f1f5f9` structural dividers and wells) to maintain pristine readability in broad daylight and mobile field environments.

## Typography

The type scale orchestrates a high-trust institutional dialogue:
- **Serif (`Merriweather`):** Reserved for display titles, page mastheads, convocation decrees, institutional headers, and official circular categories. It delivers collegiate legacy and scholarly weight.
- **Sans-Serif (`Inter`):** Drives all functional interfaces, exam tables, portal dashboards, navigation bars, and forms. Its tall x-height and neutral geometry ensure non-fatiguing reading during lengthy result inspections or administrative procedures.
- **Upper-Case Tracking:** Applied exclusively to administrative labels, departmental identifiers, and status tags (`label-md`) to ensure effortless recognition within high-density grids.

## Layout & Spacing

The portal layout adheres to a structured **12-column responsive fluid grid** with an absolute maximum content width of 1440px to retain readability on ultra-wide desktop monitors:

- **Desktop (1024px+):** 12 columns, 1.5rem gutters, 2rem margins. The page uses dedicated structural regions: Masthead/Emblem Header, Quick Ticker ribbon, Dual-column layout (Main Administrative Deck spanning 8 columns, Quick Access & Announcements Rail spanning 4 columns).
- **Tablet (768px – 1023px):** 8 columns, 1rem gutters, 1.5rem margins. The secondary rail transitions below the primary operational cards.
- **Mobile (< 768px):** 4 columns, 0.75rem gutters, 1rem margins. Complex tabular data flips to card-based stacks, and navigational mega-menus collapse into a pinned institutional bottom sheet and off-canvas drawer.
- **Spacing Cadence:** Vertical pacing strictly scales using multiples of 4px/8px, keeping compact administrative density in forms while allocating generous breathing room (`space-xl`) between university departments and announcements.

## Elevation & Depth

To avoid visual noise and ensure crisp execution across varied display calibrations, the design system employs **Low-Contrast Structural Outlines** reinforced with **Delicate Ambient Shadows**:

- **Ground Level (Elevation 0):** Canvas base (`#f8fafc`) with light-border framing (`1px solid #e2e8f0`).
- **Surface Level (Elevation 1):** Default card background (`#ffffff`), `border: 1px solid #e2e8f0`, paired with a barely perceptible ambient shadow: `0 1px 3px 0 rgba(15, 43, 72, 0.05)`.
- **Raised Interactive (Elevation 2):** Hover states, quick links, and active schedule cards: `0 4px 12px -2px rgba(26, 54, 93, 0.08), 0 2px 4px -1px rgba(26, 54, 93, 0.04)`, border shifted to `#cbd5e1`.
- **Top Tier / Modals & Mega-Flyouts (Elevation 3):** Administrative modal dialogs, search gazettes, and date pickers: `0 12px 28px -4px rgba(15, 23, 42, 0.16)`, framed by `border: 1px solid #cbd5e1`.

## Shapes

The portal implements a **Soft (`1`)** shape language:
- Standard container corner radius is fixed at **0.25rem (4px)**, with larger cards and modals at **0.5rem (8px)**.
- Highly rounded or playful pill contours are strictly avoided in administrative domains to retain architectural rigor, structure, and institutional authority.
- The only rounded exception is the circular seal/emblem container and individual counter pill badges.

## Components

### Official Notification Ticker
A persistent ribbon docked beneath the primary navigation masthead:
- Left-pinned badge: Solid Academic Crimson (`#8b1e28`) background with white `label-md` uppercase text: `"CIRCULAR / URGENT"`.
- Scrolling/stepping announcement stream in `#1e293b`, separated by saffron gold diamonds (`◆`).
- Interactive controls: Pause on hover, with previous/next discrete controls on the right edge.

### Badges & Status Indicators
- **"NEW" Badge:** Saffron Gold tint (`#fef3c7`), border `#fde68a`, text `#92400e`.
- **"URGENT / IMP":** Crimson tint (`#fee2e2`), border `#fecaca`, text `#991b1b`.
- **"DEMO / ARCHIVED":** Slate tint (`#f1f5f9`), border `#cbd5e1`, text `#475569`.
- Geometry: `rounded: 0.25rem`, padding `2px 8px`, `font-size: 11px`, font-weight 700.

### Quick Link & Department Cards
- Clean white surfaces with a top accent border: 3px solid `#1a365d` (Primary) or `#8b1e28` (Exams).
- Distinctive 40x40px icon containers tinted in soft primary slate (`#e2e8f0/50`) with deep navy iconography.
- Direct CTA text accompanied by an arrow transition (`→`) animating +3px right on hover.

### Examination & Student Schedule Cards
- Tabular card layout with high visual contrast.
- Date container styled as a calendar block: deep navy top header with white month text, bold slate day number beneath.
- Subject code rendered in mono-stylized uppercase label (`CS-601`), accompanied by title and exam slot details.

### Buttons
- **Primary:** Background `#1a365d`, text `#ffffff`, border radius `0.25rem`, font-weight 600. Hover: `#0f2b48` with a subtle elevation shift.
- **Secondary (Notice / Apply):** Background `#8b1e28`, text `#ffffff`. Hover: `#701a20`.
- **Tertiary / Outline:** Background `transparent`, border `1px solid #cbd5e1`, text `#1a365d`. Hover: background `#f1f5f9`.

### Form Fields & Search Inputs
- Inset padding `0.625rem 0.875rem`, border `1px solid #cbd5e1`, roundedness `0.25rem`.
- Focus state: `border-color: #1a365d` with a clean, low-intensity ring (`outline: 2px solid rgba(26, 54, 93, 0.2)`).
- Clear, authoritative floating labels or stacked labels using `label-lg` with red asterisks for mandatory university validation.

### Official Seal & Emblem Container
- Encased within an optic-white circular shield with an inner golden-ochre hairline border (`1px solid #f59e0b`) and subtle shadow to ensure clear contrast against both light and deep navy mastheads.